import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paid-licence',
  templateUrl: './paid-licence.page.html',
  styleUrls: ['./paid-licence.page.scss'],
})
export class PaidLicencePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
