export const apiConfig = {
  downloadPdf: "/claim/get-claim-pdf",
  getDl: "/account/barcode-reader",
};
