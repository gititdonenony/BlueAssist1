import { Component, OnInit, ViewChild } from '@angular/core';
import { IonTabs } from '@ionic/angular';
import { Router } from '@angular/router';
import { NavController, MenuController, ModalController } from '@ionic/angular';
import { CallLoggedComponent } from './../../call-logged/call-logged.component';
import { StartYourAccidentReportComponent } from './../../start-your-accident-report/start-your-accident-report.component';


@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.page.html',
  styleUrls: ['./tabs.page.scss'],
})
export class TabsPage implements OnInit {

  selectTab: any;
  // eslint-disable-next-line @typescript-eslint/member-ordering
  @ViewChild('tabs') tabs: IonTabs;

  constructor( private route: Router,private modalCtrl: ModalController) {}

  ngOnInit() {
  }

  setCurrentTab(event) {
    this.selectTab = this.tabs.getSelected();
  }

  async lock(lockdeta) {
    const popover = await this.modalCtrl.create({
      component: CallLoggedComponent,
      cssClass: 'login-unlock-modal-class',
    });
    return await popover.present();
  }

  async lockshop(lockdeta) {
    const popover = await this.modalCtrl.create({
      component: StartYourAccidentReportComponent,
      cssClass: 'login-unlock-modal-class',
    });
    return await popover.present();
  }

  licencerenewalhome(){
    this.route.navigate(['/licence-renewal-home']);
  }
  trafficFineshome(){
    this.route.navigate(['/confirm-id']);
  }
  shophome(){
    this.route.navigate(['/shop-product']);
  }

}
