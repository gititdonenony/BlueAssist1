import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { KmlLayerPageRoutingModule } from './kml-layer-routing.module';

import { KmlLayerPage } from './kml-layer.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    KmlLayerPageRoutingModule
  ],
  declarations: [KmlLayerPage]
})
export class KmlLayerPageModule {}
