import { Component, ElementRef, NgZone, OnInit, ViewChild } from '@angular/core';
import * as L from 'leaflet';
// import { GeolocationOptions, Geoposition, PositionError } from '@ionic-native/geolocation';
// import { Geolocation } from '@capacitor/geolocation';

 declare var google: any;
@Component({
  selector: 'app-kml-layer',
  templateUrl: './kml-layer.page.html',
  styleUrls: ['./kml-layer.page.scss'],
})
export class KmlLayerPage implements OnInit {
  map: any;
  data: any;
  @ViewChild('map', { read: ElementRef, static: false }) mapRef: ElementRef | any;
  constructor(
  ) { }

  ngOnInit() {

  }

  //call the showMap method after page is rendered
  ionViewDidEnter() {
    let result = {
      latitude: 22.9375,
      longitude: 30.5595,
      addressLines: 'Technogiq Solutions Pvt Ltd.',
      countryName: 'India',
      administrativeArea: "Madhya Pradesh",
      locality: "Bhopal",
      subLocality: "AreraColony"
    }
    this.showMap(result)
  }


  //Load the map on the page
  showMap(result: any) {
    const location = new google.maps.LatLng(result.latitude, result.longitude) //coratlim goa
    const options = {
      center: location,
      zoom: 3,
      disableDefaultUI: true,
      zoomControl: true,
      mapTypeId: 'roadmap',
      mapTypeControl: true,
      controlSize: 25,
      mapTypeControlOptions: {
        mapTypeIds: ['satellite', 'roadmap'],
        style: google.maps.MapTypeControlStyle.DEFAULT,
        position: google.maps.ControlPosition.RIGHT_CENTER,
      },
      zoomControlOptions: {
        position: google.maps.ControlPosition.RIGHT_CENTER,
      },
    }
    this.map = new google.maps.Map(this.mapRef.nativeElement, options)
   // this.addMarker(result);
      const kmlUrl = 'src/assets/KML Files/Air Ambulance Support/doc.kml';
      const kmlLayer = new google.maps.KmlLayer({
      url: kmlUrl,
      map: this.map,
      preserveViewport: true
    });
     fetch('../../../assets/KML Files/Air Ambulance Support.geojson')
    .then(res => res.json())
        .then(data => {
          console.log(data);
          this.data=data;
        })
    
    const map = L.map('map').setView([51.505, -0.09], 13);
    const geojsonLayer = L.geoJSON(this.data).addTo(map);
  }
  
  //Add Marker to the google map
  addMarker(result: any) {
    let position = new google.maps.LatLng(result.latitude, result.longitude);
    let mapMarker = new google.maps.Marker({
      position: position,
      title: result.addressLines,
      latitude: result.latitude,
      longitude: result.longitude
    })
    mapMarker.setMap(this.map);
    this.addInfoWindowToMareker(mapMarker, result);
  }

  addInfoWindowToMareker(marker: any, result: any) {
    let infoWindowContnet = '<div id="content">' +
      '<h2 id="firstHeading" class="firstHeading">' + marker.title + '</h2>' +
      '<p> Latitude: ' + marker.latitude + '</p>' +
      '<p> Longitude: ' + marker.longitude + '</p>' +
      '</div>';

    let infoWindow = new google.maps.InfoWindow({
      Content: infoWindowContnet,
      pixelOffSet: new google.maps.Size(0, 20),

    })

    // marker.addListener('click', () => {
    //   this.addressPopup(result, this.address);
    // })
  }




}
