/* eslint-disable eqeqeq */
/* eslint-disable @typescript-eslint/naming-convention */
import { Component, OnInit } from '@angular/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { ApiService } from 'src/app/services/api.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MessageService } from 'src/app/services/message.service';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-pothole-road-scene-photos',
  templateUrl: './pothole-road-scene-photos.page.html',
  styleUrls: ['./pothole-road-scene-photos.page.scss'],
})
export class PotholeRoadScenePhotosPage implements OnInit {
  userObject: any;
  token: any;
  base64ResponseForIncident: any;
  incidentImageName: any;
  incidentImage: any[] = [];
  showImage = false;
  getImageUrl: any;
  uploadedGalleryImageURL: any;
  uploadedImageName: any;
  incidentImgName = [];
  img1: any;
  img2: any;
  img3: any;
  img4: any;
  handlerMessage: string;
  imgLength: any;

  constructor(
    private apiService: ApiService,
    private loaderService: LoaderService,
    private messageService: MessageService,
    private route: Router,
    private alertController: AlertController
  ) {}

  ngOnInit() {
    this.incidentImage = JSON.parse(localStorage.getItem('pothole_images'))
      ? JSON.parse(localStorage.getItem('pothole_images'))
      : [];
    this.userObject = JSON.parse(localStorage.getItem('userLoginData'));
    if (this.userObject) {
      this.token = this.userObject.token;
    }
  }
  ionViewWillEnter() {
    localStorage.setItem(
      'pothole-photo-lenght',
      '' + this.incidentImage.length
    );
  }
  async captureImage() {
    this.imgLength = this.incidentImage.length + 1;
    localStorage.setItem('pothole-photo-lenght', '' + this.imgLength);
    if (this.incidentImage.length <= 3) {
      const image = await Camera.getPhoto({
        quality: 30,
        allowEditing: false,
        resultType: CameraResultType.Base64,
        source: CameraSource.Camera,
        saveToGallery: false,
      });
      const body = {
        imageFile: image.base64String.toString(),
        imageType: image.format,
      };
      this.loaderService.showLoader();
      this.apiService.imageBase64Upload(body, this.token).subscribe(
        (data: any) => {
          this.loaderService.hideLoader();
          const imgData = {
            name: data.data.imagename,
            url: data.data.imagepath,
          };
          this.incidentImage.push(imgData);
          localStorage.setItem(
            'pothole_images',
            JSON.stringify(this.incidentImage)
          );
        },
        (err) => {
          this.loaderService.hideLoader();
          if (err.hasOwnProperty('status')) {
            if (err.status == '401') {
              this.messageService.presentErrorToast('Something Wrong');
            }
          }
        }
      );
    } else {
      this.messageService.presentToast('You can only select four Images');
    }
  }
  async presentAlert(index) {
    const alert = await this.alertController.create({
      header: 'Alert',
      message: 'Are you sure  to  remove this photo',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            this.handlerMessage = 'Alert canceled';
          },
        },
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            this.handlerMessage = 'Alert confirmed';
            this.incidentImage.splice(index, 1);
            localStorage.setItem(
              'pothole_images',
              JSON.stringify(this.incidentImage)
            );
            this.imgLength = localStorage.getItem('pothole_images');
            this.imgLength = JSON.parse(this.imgLength).length;
            localStorage.setItem('pothole-photo-lenght', '' + this.imgLength);
          },
        },
      ],
    });
    await alert.present();
  }
  submitIncident() {
    console.log(this.incidentImage);
    if (this.incidentImgName.length == 0 && this.incidentImage.length == 0) {
      this.messageService.presentErrorToast(
        'You have to click atleast one picture.'
      );
      return false;
    }
    const formData = new FormData();
    formData.append(
      'img1',
      this.incidentImage[0] ? this.incidentImage[0].name : ''
    );
    formData.append(
      'img2',
      this.incidentImage[1] ? this.incidentImage[1].name : ''
    );
    formData.append(
      'img3',
      this.incidentImage[2] ? this.incidentImage[2].name : ''
    );
    formData.append(
      'img4',
      this.incidentImage[3] ? this.incidentImage[3].name : ''
    );
    formData.append('type', 'pothole');
    localStorage.setItem(
      'pothole-road-scene-photos',
      JSON.stringify(this.incidentImage)
    );
    this.route.navigate(['/incident-photos']);
  }

  getPotholeByType() {
    const id = localStorage.getItem('pothole')
      ? localStorage.getItem('pothole')
      : '';
    this.apiService.getPothole('pothole', this.token, id).subscribe(
      (res: any) => {
        console.log(res);
        if (res.hasOwnProperty('operation')) {
          if (res.operation === 'success') {
            this.showImage = true;
            const url1 = `${res.data[0].image_full_path}${res.data[0].pothole_img1}`;
            const url2 = `${res.data[0].image_full_path}${res.data[0].pothole_img2}`;
            const url3 = `${res.data[0].image_full_path}${res.data[0].pothole_img3}`;
            const url4 = `${res.data[0].image_full_path}${res.data[0].pothole_img4}`;

            this.incidentImage = [
              {
                image_url:
                  res.data[0].pothole_img1 &&
                  res.data[0].pothole_img1 !== 'undefined'
                    ? url1
                    : '',
                name: res.data[0].pothole_img1,
              },
              {
                image_url:
                  res.data[0].pothole_img2 &&
                  res.data[0].pothole_img2 !== 'undefined'
                    ? url2
                    : '',
                name: res.data[0].pothole_img2,
              },
              {
                image_url:
                  res.data[0].pothole_img3 &&
                  res.data[0].pothole_img3 !== 'undefined'
                    ? url3
                    : '',
                name: res.data[0].pothole_img3,
              },
              {
                image_url:
                  res.data[0].pothole_img4 &&
                  res.data[0].pothole_img4 !== 'undefined'
                    ? url4
                    : '',
                name: res.data[0].pothole_img4,
              },
            ];
            this.incidentImage = this.incidentImage.filter(
              (ele) => ele.image_url !== ''
            );
          }
        }
      },
      (err) => {
        if (err.hasOwnProperty('status')) {
          if (err.status == '401') {
            this.messageService.presentErrorToast('Something Wrong');
          } else {
            this.messageService.presentErrorToast('Something Wrong');
          }
        } else {
          this.messageService.presentErrorToast('Something Wrong');
        }
      }
    );
  }
}
