import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-confirmation',
  templateUrl: './shop-confirmation.page.html',
  styleUrls: ['./shop-confirmation.page.scss'],
})
export class ShopConfirmationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
