import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accident-scene',
  templateUrl: './accident-scene.page.html',
  styleUrls: ['./accident-scene.page.scss'],
})
export class AccidentScenePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
