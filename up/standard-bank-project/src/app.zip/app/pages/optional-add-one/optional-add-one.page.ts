import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-optional-add-one',
  templateUrl: './optional-add-one.page.html',
  styleUrls: ['./optional-add-one.page.scss'],
})
export class OptionalAddOnePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
