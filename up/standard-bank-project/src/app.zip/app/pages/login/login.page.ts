/* eslint-disable eqeqeq */
/* eslint-disable @typescript-eslint/naming-convention */
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
//import validator and FormBuilder
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
} from '@angular/forms';
import { ApiService } from 'src/app/services/api.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MessageService } from 'src/app/services/message.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  //Create FormGroup
  passwordToggleIcon = 'Show';
  loginForm: FormGroup;
  showPassword = false;
  constructor(
    private route: Router,
    private fb: FormBuilder,
    private apiService: ApiService,
    private loaderService: LoaderService,
    private messageService: MessageService
  ) {
    this.myForm();
  }

  ngOnInit() {}
  toggleNewPassword() {
    this.showPassword = !this.showPassword;
    if (this.passwordToggleIcon === 'Show') {
      this.passwordToggleIcon = 'Hide';
    } else {
      this.passwordToggleIcon = 'Show';
    }
  }
  //Create required field validator for name
  myForm() {
    this.loginForm = this.fb.group({
      name: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  login() {
    if (this.loginForm.value.name == '') {
      this.messageService.presentErrorToast('Enter your Username');
    } else if (this.loginForm.value.password == '') {
      this.messageService.presentErrorToast('Enter your Password');
    } else if (this.loginForm.valid) {
      const body = {
        action: 'Login_progress',
        // eslint-disable-next-line @typescript-eslint/naming-convention
        Username: this.loginForm.value.name,
        Password: this.loginForm.value.password,
      };
      this.loaderService.showLoader();
      this.apiService.getLogin(body).subscribe(
        (res: any) => {
          if (res.hasOwnProperty('operation')) {
            if (res.operation === 'success') {
              this.loaderService.hideLoader();
              localStorage.setItem('userLoginData', JSON.stringify(res));
              this.userInfo(res.token);
              this.messageService.presentSuccessToast(
                'You are successfully logged in'
              );
              const value = localStorage.getItem('hasSeenPersonalInfo');
              if (value && value === 'true') {
                this.route.navigate(['/tabs/profile']);
              } else {
                this.route.navigate(['/login-success']);
              }
            }
          }
        },
        (err) => {
          if (err.hasOwnProperty('status')) {
            if (err.status == '401') {
              this.loaderService.hideLoader();
              this.messageService.presentErrorToast('Invalid Login Credentials');
            } else {
              this.loaderService.hideLoader();
              this.messageService.presentErrorToast('Something Wrong');
            }
          } else {
            this.loaderService.hideLoader();
            this.messageService.presentErrorToast('Something Wrong');
          }
        }
      );
    }
  }

  //? Getting user info for sidebar
  async userInfo(token): Promise<void> {
    return new Promise(async (resolve) => {
      this.apiService.userInfomation(token).subscribe((res: any) => {
        localStorage.setItem('userInfo', JSON.stringify(res));
        resolve();
      });
    });
  }
}
