import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-licence-reneval-home',
  templateUrl: './licence-reneval-home.page.html',
  styleUrls: ['./licence-reneval-home.page.scss'],
})
export class LicenceRenevalHomePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
