import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-finish-home',
  templateUrl: './finish-home.page.html',
  styleUrls: ['./finish-home.page.scss'],
})
export class FinishHomePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
