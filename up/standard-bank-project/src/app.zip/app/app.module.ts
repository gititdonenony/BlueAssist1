import { BackgroundMode } from '@awesome-cordova-plugins/background-mode/ngx';
import { HomeAssistComponent } from './home-assist/home-assist.component';
import { RoadsideAssistComponent } from './roadside-assist/roadside-assist.component';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';

import { Shake } from '@ionic-native/shake/ngx';
import { HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './component/header/header.component';
import { EventService } from './services/event.service';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { NativeGeocoder } from '@ionic-native/native-geocoder/ngx';
import { GoogleMapsModule } from '@angular/google-maps';
import { Vibration } from '@awesome-cordova-plugins/vibration/ngx';
import { EmailComposer } from '@awesome-cordova-plugins/email-composer/ngx';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
@NgModule({
  declarations: [AppComponent, RoadsideAssistComponent, HomeAssistComponent],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    HttpClientModule,
    GoogleMapsModule,
    BrowserAnimationsModule,
  ],
  providers: [
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    Shake,
    NativeGeocoder,
    Vibration,
    EmailComposer,
    EventService,
    BackgroundMode
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
