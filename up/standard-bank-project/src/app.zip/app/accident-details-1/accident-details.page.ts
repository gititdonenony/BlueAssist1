import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accident-details',
  templateUrl: './accident-details.page.html',
  styleUrls: ['./accident-details.page.scss'],
})
export class AccidentDetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
