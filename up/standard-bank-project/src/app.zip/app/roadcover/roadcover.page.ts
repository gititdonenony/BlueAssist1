import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roadcover',
  templateUrl: './roadcover.page.html',
  styleUrls: ['./roadcover.page.scss'],
})
export class RoadcoverPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
