import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-choose-a-bundle',
  templateUrl: './choose-a-bundle.page.html',
  styleUrls: ['./choose-a-bundle.page.scss'],
})
export class ChooseABundlePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
