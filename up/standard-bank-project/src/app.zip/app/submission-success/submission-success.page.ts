import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-submission-success',
  templateUrl: './submission-success.page.html',
  styleUrls: ['./submission-success.page.scss'],
})
export class SubmissionSuccessPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
