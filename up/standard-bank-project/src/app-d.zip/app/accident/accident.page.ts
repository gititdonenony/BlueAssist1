import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accident',
  templateUrl: './accident.page.html',
  styleUrls: ['./accident.page.scss'],
})
export class AccidentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
