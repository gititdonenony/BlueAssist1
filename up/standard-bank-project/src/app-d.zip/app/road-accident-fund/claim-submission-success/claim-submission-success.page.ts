import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-submission-success',
  templateUrl: './claim-submission-success.page.html',
  styleUrls: ['./claim-submission-success.page.scss'],
})
export class ClaimSubmissionSuccessPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
