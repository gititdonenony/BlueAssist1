import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roadcove',
  templateUrl: './roadcove.page.html',
  styleUrls: ['./roadcove.page.scss'],
})
export class RoadcovePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
