import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-confermation',
  templateUrl: './shop-confermation.page.html',
  styleUrls: ['./shop-confermation.page.scss'],
})
export class ShopConfermationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
