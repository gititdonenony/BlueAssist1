describe('LoaderService', () => {
  it('should be created', () => {
    expect(true).toBeTruthy();
  });
});
