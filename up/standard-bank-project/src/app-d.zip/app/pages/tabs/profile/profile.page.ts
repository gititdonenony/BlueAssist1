/* eslint-disable object-shorthand */
import { NgZone, ViewChild } from '@angular/core';
/* eslint-disable curly */
/* eslint-disable max-len */
import { ApiService } from 'src/app/services/api.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuController, ModalController, Platform } from '@ionic/angular';
import { HomeAssistComponent } from './../../../home-assist/home-assist.component';
import { RoadsideAssistComponent } from './../../../roadside-assist/roadside-assist.component';
import { PtoholeReportMainMenuComponent } from './../../../ptohole-report-main-menu/ptohole-report-main-menu.component';
import { CallLoggedComponent } from './../../../call-logged/call-logged.component';
import {
  NativeGeocoder,
  NativeGeocoderOptions,
  NativeGeocoderResult,
} from '@ionic-native/native-geocoder/ngx';
import { Geolocation } from '@capacitor/geolocation';
//import { AppRate } from '@ionic-native/app-rate/ngx';
import { MapInfoWindow, MapMarker } from '@angular/google-maps';
import { Vibration } from '@awesome-cordova-plugins/vibration/ngx';
import { EventService } from 'src/app/services/event.service';
import { Subscription, timer } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { style } from '@angular/animations';
// import { map } from 'jquery';
// import { RSA_NO_PADDING } from 'constants';
enum responsezone {
  RESPONSEZONE1 = "You Are in Air Ambulance Support Response Zone",
  RESPONSEZONE2 = "You Are in CASIC Coverage Response Zone",
  RESPONSEZONE3 = "You Are in Private Medical Response Zone",
  RESPONSEZONE4 = "You Are in SAPS & Public Ambulance Response Zone",
  RESPONSEZONE5 = "You Are not in Response Zone"
}

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
  @ViewChild(MapInfoWindow) infoWindow: MapInfoWindow;
  slideOpts = {};
  stories: any[] = [];
  buttonValue = 'grid';
  buttonItems: any[] = [];
  posts: any[] = [];
  userAddress: any;
  display: any;
  lat: any;
  lng: any;

  allKmljsonFiles = [
    { "name": '../../../assets/kml-json/Air_Ambulance_Support.geojson' },
    { "name": '../../../assets/kml-json/SAPS&PublicAmbulance.geojson' },
    { "name": '../../../assets/kml-json/PrivateMedicalResponse.geojson' },
    { "name": '../../../assets/kml-json/CASICoverage2022-09-07.geojson' },
  ]


  featureCoordinates = []
  responseAirAmbulane = []
  responseSAPS = []
  responsePrivateMedical = []
  responseCASI = []
  isAnyResponseArea: boolean = false
  responseText = ''
  responseStatus: any
  center: google.maps.LatLngLiteral = {
    lat: 24,
    lng: 12,
  };
  zoom = 8;

  markerOptions: google.maps.MarkerOptions = {
    draggable: false,
    icon: {
      url: '/assets/Subtract.png',
      scaledSize: new google.maps.Size(32, 34),
    },
  };
  mapOptions: google.maps.MapOptions = {
    disableDefaultUI: true,
    streetViewControl: false,
    zoomControl: true,
    mapTypeId: 'roadmap',
    mapTypeControl: true,
    controlSize: 25,
    mapTypeControlOptions: {
      mapTypeIds: ['hybrid', 'roadmap',],
      style: google.maps.MapTypeControlStyle.DEFAULT,
      position: google.maps.ControlPosition.RIGHT_CENTER
    },
    zoomControlOptions: {
      position: google.maps.ControlPosition.RIGHT_CENTER,
    },


    fullscreenControl: false,
    styles: [
      {
        featureType: 'administrative',
        elementType: 'geometry',
        stylers: [
          {
            visibility: 'off',
          },
        ],
      },
      {
        featureType: 'poi',
        stylers: [
          {
            visibility: 'off',
          },
        ],
      },
      {
        featureType: 'road',
        elementType: 'labels.icon',
        stylers: [
          {
            visibility: 'off',
          },
        ],
      },
      {
        featureType: 'transit',
        stylers: [
          {
            visibility: 'off',
          },
        ],
      },
    ],
  };
  isPanicActivated: any = false;
  markerPosition: google.maps.LatLngLiteral;

  address: any = {
    areasOfInterest: '',
    subLocality: '',
    locality: '',
    subAdministrativeArea: '',
    administrativeArea: '',
    postalCode: '',
    countryName: '',
    countryCode: '',
  };
  subcribeToPanic: Subscription;
  isLocationPermission = true;

  constructor(
    private route: Router,
    private modalCtrl: ModalController,
    private apiService: ApiService,
    private nativeGeocoder: NativeGeocoder,
    private platform: Platform,
    public ngZone: NgZone, //private appRate: AppRate
    private vibration: Vibration,
    private eventService: EventService,
    private menuctrl: MenuController
  ) {
    const markerUrl = `${JSON.parse(localStorage.getItem('userInfo')).image_full_path
      }${JSON.parse(localStorage.getItem('userInfo')).marker_img}`;
    this.markerOptions.icon = {
      url: markerUrl,
      scaledSize: new google.maps.Size(53, 72),
    };
    this.initialize();
  }
  initialize() {
    this.fetchAllKmlCoordinates()
    //for manual checking
    // this.isAnyResponseArea = false
    // this.responseStatus = ''
    // this.checkAllKmlCoordinates(20.2986635, 85.860711)
    this.apiService
      .askToTurnOnGPS()
      .then((re) => {
        if (re) {
          this.watchPosition();
        } else {
          this.getDeviceLocation();
        }
      })
      .catch((err) => { });
  }
  sideMenuClose() {
    this.menuctrl.close();
  }
  // getDiv(){
  //   document.getElementById("DivID")
  // }
  getDeviceLocation() {
    console.log("enter getDeviceLocation");
    this.apiService
      .printCurrentPosition()
      .then((res) => {
        const location = res.coords;
        this.lat = location.latitude;
        this.lng = location.longitude;
        console.log("In getDeviceLocation Method");
        console.log("Latitude - " + this.lat + "Longitude - " + this.lng);
        this.center = { lat: this.lat - 0.003, lng: this.lng };
        this.markerPosition = { lat: this.lat, lng: this.lng };
        this.zoom = 15;
        this.reverseGeocode(location.latitude, location.longitude);
        this.isAnyResponseArea = false
        this.responseStatus = ''
        this.checkAllKmlCoordinates(location.latitude, location.longitude)
      })
      .catch((err) => {
        if (this.isLocationPermission) {
          window.alert('app will not work proper if you denied for location');
          this.isLocationPermission = false;
        }
      });
  }

  fetchAllKmlCoordinates() {
    console.log("enter in kmlCoordinates");
    this.allKmljsonFiles.forEach(element => {
      fetch(element.name)
        .then(res => res.json())
        .then(data => {
          console.log(data.name);
          if (data.name === 'Air Ambulance Support') {
            data.features.forEach(geo => {
              geo.geometry.coordinates[0].forEach(cords => {
                this.responseAirAmbulane.push(cords)
              });
            });
          }
          if (data.name === 'SAPS and Public Ambulance') {
            data.features.forEach(geo => {
              geo.geometry.coordinates[0].forEach(cords => {
                this.responseSAPS.push(cords)
              });
            });
          }
          if (data.name === 'Private Medical Response') {
            data.features.forEach(geo => {
              geo.geometry.coordinates[0].forEach(cords => {
                this.responsePrivateMedical.push(cords)
              });
            });
          }
          if (data.name === 'CASI Coverage') {
            data.features.forEach(geo => {
              geo.geometry.coordinates[0].forEach(cords => {
                this.responseCASI.push(cords)
              });
            });
          }

          //Total all the coordinates
          // data.features.forEach(geo => {
          //   geo.geometry.coordinates[0].forEach(cords => {
          //     this.featureCoordinates.push(cords)
          //   });
          // });
        })
    });
    console.log("leave in kmlCoordinates");
  }

  checkAllKmlCoordinates(lat, lng) {
    // console.log("enter in set value for isAnyResponseArea");
    // console.log(this.responseAirAmbulane);
    // console.log(this.responseSAPS);
    // console.log(this.responsePrivateMedical);
    // console.log(this.responseCASI);
    setTimeout(() => {
      this.responseAirAmbulane.forEach(element => {
        if (lat == element[0] && lng == element[1]) {
          this.isAnyResponseArea = true
          this.responseStatus = 1
        }
      });
      this.responseSAPS.forEach(element => {
        if (lat == element[0] && lng == element[1]) {
          this.isAnyResponseArea = true
          this.responseStatus = 2
        }
      });
      this.responsePrivateMedical.forEach(element => {
        if (lat == element[0] && lng == element[1]) {
          this.isAnyResponseArea = true
          this.responseStatus = 3
        }
      });
      this.responseCASI.forEach(element => {
        if (lat == element[0] && lng == element[1]) {
          this.isAnyResponseArea = true
          this.responseStatus = 4
        }
      });
      this.callCheck(this.responseStatus)
    }, 3000);
  }

  callCheck(responseStatus: any) {
    console.log("enter in printing message");
    if (this.isAnyResponseArea && responseStatus == 1) {
      this.responseText = responsezone.RESPONSEZONE1
    }
    else if (this.isAnyResponseArea && responseStatus == 2) {
      this.responseText = responsezone.RESPONSEZONE2
    }
    else if (this.isAnyResponseArea && responseStatus == 3) {
      this.responseText = responsezone.RESPONSEZONE3
    }
    else if (this.isAnyResponseArea && responseStatus == 4) {
      this.responseText = responsezone.RESPONSEZONE4
    }
    else {
      this.responseText = responsezone.RESPONSEZONE5
    }
    console.log(this.isAnyResponseArea + " " + this.responseText);
  }

  async watchPosition() {
    console.log("enter watchPosition");
    try {
      Geolocation.watchPosition({}, (position, err) => {
        this.ngZone.run(() => {
          if (err) {
            return;
          }
          this.lat = position.coords.latitude;
          this.lng = position.coords.longitude;
          console.log("In watchPosition Method");
          console.log("Latitude - " + this.lat + "Longitude - " + this.lng);
          this.center = { lat: this.lat - 0.003, lng: this.lng };
          this.markerPosition = { lat: this.lat, lng: this.lng };
          this.zoom = 15;
          this.reverseGeocode(this.lat, this.lng);
          this.isAnyResponseArea = false
          this.responseStatus = ''
          this.checkAllKmlCoordinates(this.lat, this.lng)
        });
      });
    } catch (err) { }
  }

  openInfoWindow(marker: MapMarker) {
    console.log("enter");

    this.infoWindow.open(marker);

  }
  ngOnInit() {
    this.stories = [
      { name: 'Pathole Assist', src: 'assets/icon/car.png' },
      { name: 'Home Assist', src: 'assets/icon/car.png' },
      { name: 'Roadside Assist', src: 'assets/icon/car.png' },
      { name: 'RAF Claim', src: 'assets/icon/car.png' },
    ];
    this.slideOpts = {
      slidesPerView: this.checkScreen(),
      slideShadows: true,
    };
    this.buttonItems = [
      { value: 'grid', icon: 'grid' },
      { value: 'reels', icon: 'film' },
      { value: 'photos', icon: 'images' },
    ];
    this.posts = [
      { id: 1, url: 'assets/imgs/posts/1.jpg' },
      { id: 2, url: 'assets/imgs/posts/2.jpg' },
      { id: 3, url: 'assets/imgs/posts/3.png' },
      { id: 4, url: 'assets/imgs/posts/4.png' },
      { id: 9, url: 'assets/imgs/posts/5.jpg' },
      { id: 6, url: 'assets/imgs/posts/6.png' },
      { id: 5, url: 'assets/imgs/posts/7.png' },
      { id: 8, url: 'assets/imgs/posts/8.jpg' },
      { id: 7, url: 'assets/imgs/posts/9.png' },
      { id: 10, url: 'assets/imgs/posts/10.png' },
      { id: 11, url: 'assets/imgs/posts/11.png' },
      { id: 12, url: 'assets/imgs/posts/12.png' },
    ];

    this.eventService.get('isPanicActivated').subscribe((data: any) => {
      if (
        data.isHomepanicActivate === 0 ||
        data.isRoadpanicActivate === 0 ||
        data.isShakepanicActivate === 0 ||
        localStorage.getItem('isShakePanicAlertOn') === 'true' ||
        localStorage.getItem('isHomePanicAlertOn') === 'true' ||
        localStorage.getItem('isRoadPanicAlertOn') === 'true' ||
        localStorage.getItem('isFabPanicAlertOn') === 'true'
      ) {
        this.isPanicActivated = true;
      } else {
        this.isPanicActivated = false;
      }
    });
  }

  async lock(lockdeta) {
    const popover = await this.modalCtrl.create({
      component: HomeAssistComponent,
      cssClass: 'login-unlock-modal-class',
      componentProps: { panicStatus: this.isPanicActivated },
    });
    return await popover.present();
  }

  async roadside(lockdeta) {
    const popover = await this.modalCtrl.create({
      component: RoadsideAssistComponent,
      cssClass: 'login-unlock-modal-class',
      componentProps: { panicStatus: this.isPanicActivated },
    });
    return await popover.present();
  }

  async lockshop() {
    this.route.navigate(['/pothole']);
  }
  async lockCall() {
    if (!this.isPanicActivated) {
      this.isPanicActivated = true;
      localStorage.setItem('isFabPanicAlertOn', 'true');
      this.showPanicConfirmPopup();
      this.callPanicAlertRepetadely();
    }
  }

  checkScreen() {
    const innerWidth = window.innerWidth;
    switch (true) {
      case 340 > innerWidth:
        return this.checkLength(5.5);
      case 340 <= innerWidth && innerWidth <= 400:
        return this.checkLength(5.5);
      case 401 <= innerWidth && innerWidth <= 700:
        return this.checkLength(6.5);
      case 701 <= innerWidth && innerWidth <= 900:
        return this.checkLength(7.5);
      case 901 <= innerWidth:
        return this.checkLength(9.5);
    }
  }

  checkLength(val) {
    const length = this.stories.length;
    return val < length ? val : length;
  }

  buttonsChanged(event) {
    this.buttonValue = event.detail.value;
  }

  //? get user address
  reverseGeocode(lat, lng) {
    if (this.platform.is('cordova')) {
      const options: NativeGeocoderOptions = {
        useLocale: true,
        maxResults: 5,
      };
      this.nativeGeocoder
        .reverseGeocode(lat, lng, options)
        .then((result: NativeGeocoderResult[]) => {
          this.userAddress = `${result[0].areasOfInterest} ${result[0].subLocality} ${result[0].locality},${result[0].subAdministrativeArea},${result[0].administrativeArea},${result[0].countryName}`;
        })
        .catch((error: any) => console.log(error));
    } else {
    }
  }

  //?  create panic alert
  async createPanicAlert() {
    const body = {
      subPanicType: '',
      panicType: '',
    };
    return new Promise((resolve) => {
      this.apiService
        .printCurrentPosition()
        .then((cords) => {
          const response = this.apiService.postPanic(cords.coords, body);
          response.subscribe(
            async (res: any) => {
              if (res.operation === 'success' && res.status) {
                this.stop();
              }
            },
            (err) => window.alert(err.data)
          );
        })
        .catch(async (err) => {
          window.alert('Please enable location and try again.');
        });
    });
  }

  //? show popup
  async showPanicConfirmPopup() {
    this.vibration.vibrate(1000);
    const popover = await this.modalCtrl.create({
      component: CallLoggedComponent,
      cssClass: 'login-unlock-modal-class',
    });
    await popover.present();
  }

  //? call panic alert every five min
  callPanicAlertRepetadely() {
    this.subcribeToPanic = timer(0, environment.panicApiCallTime)
      .pipe(switchMap(async () => this.createPanicAlert()))
      .subscribe((res) => console.log('res', res));
  }

  //? disable the reapeating panic api call
  stop() {
    localStorage.setItem('isFabPanicAlertOn', 'false');
    this.isPanicActivated = false;
    this.subcribeToPanic.unsubscribe();
  }
}
