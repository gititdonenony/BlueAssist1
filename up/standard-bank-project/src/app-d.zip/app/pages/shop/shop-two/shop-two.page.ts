import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-two',
  templateUrl: './shop-two.page.html',
  styleUrls: ['./shop-two.page.scss'],
})
export class ShopTwoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
