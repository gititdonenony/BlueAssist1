import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-home',
  templateUrl: './shop-home.page.html',
  styleUrls: ['./shop-home.page.scss'],
})
export class ShopHomePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
