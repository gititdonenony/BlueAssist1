import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-add-card-two',
  templateUrl: './shop-add-card-two.page.html',
  styleUrls: ['./shop-add-card-two.page.scss'],
})
export class ShopAddCardTwoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
