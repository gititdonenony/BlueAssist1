import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-add-card',
  templateUrl: './shop-add-card.page.html',
  styleUrls: ['./shop-add-card.page.scss'],
})
export class ShopAddCardPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
