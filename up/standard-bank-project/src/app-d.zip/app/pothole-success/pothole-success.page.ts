import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pothole-success',
  templateUrl: './pothole-success.page.html',
  styleUrls: ['./pothole-success.page.scss'],
})
export class PotholeSuccessPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
